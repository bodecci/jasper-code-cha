
def lambda_handler(event, context):
    print("Hello Dillan")
    return {
        'statusCode': 200,
        'body': 'Hello Dillan'
    }

  